/* This file is auto generated, version 31 */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#31 SMP Wed Aug 19 11:05:46 EDT 2015"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "DO-CR"
#define LINUX_COMPILER "gcc version 4.9.2 (Ubuntu 4.9.2-10ubuntu13) "
